(function(){
'use strict';let previewTimer=null,conversion=0,device='default',wallReady=false,lastWallSignature='',coordinates=null,groupGuardUntil=0;let socket,uuid,action,settings={},lastStatus='연결 중…',pending=null,editingUntil=0;
const el=id=>document.getElementById(id);
function status(text){lastStatus=text;el('status').textContent=text;el('status').classList.toggle('error',/오류|실패|끊겼|못했/.test(text));}
let previewImage=null,previewRevision=0;
function viewPreview(){
 el('gapOptions').style.display=settings.includeGaps===true?'block':'none';el('gapValue').textContent=settings.gapPercent===undefined?30:settings.gapPercent;
 if(!previewImage)return;const l=GifEngine.wallLayout(settings),canvas=el('preview');canvas.width=l.width;canvas.height=l.height;
 const ctx=canvas.getContext('2d');GifEngine.drawWall(ctx,previewImage,settings);ctx.fillStyle='#303136';
 for(let col=1;col<l.columns;col++)ctx.fillRect(col*144+(col-1)*l.gap,0,l.gap,l.height);
 for(let row=1;row<l.rows;row++)ctx.fillRect(0,row*144+(row-1)*l.gap,l.width,l.gap);
}
function previewFrame(src){const revision=++previewRevision,img=new Image();img.onload=()=>{if(revision!==previewRevision)return;previewImage=img;viewPreview();};img.src=src;}

function targetUI(){const kind=el('clickAction').value,has=['website','folder','file'].includes(kind);el('targetRow').style.display=has?'block':'none';el('browserRow').style.display=kind==='website'?'block':'none';el('folderRow').style.display=kind==='folder'?'block':'none';el('testAction').style.display=has?'block':'none';el('browse').style.display=(kind==='folder'||kind==='file')?'block':'none';el('browse').textContent=kind==='folder'?'폴더 선택':'파일 선택';el('targetLabel').textContent=kind==='website'?'웹사이트 주소':kind==='folder'?'폴더 경로':'프로그램·파일 경로';el('clickTarget').placeholder=kind==='website'?'https://example.com':kind==='folder'?'C:\\Users\\사용자\\Documents':'C:\\Program Files\\프로그램\\app.exe';el('actionHint').textContent=kind==='pause'?'버튼을 누르면 같은 화면 그룹의 GIF를 재생·정지합니다.':kind==='none'?'버튼을 눌러도 실행하지 않습니다.':'버튼을 눌러 실행해도 GIF는 계속 움직입니다.';}
function tileOptions(){const previous=el('tile').value||settings.tile||'',cols=Number(settings.columns)||3,rows=cols===5?3:2;el('tile').innerHTML='<option value="">기기 버튼 위치에 맞춤</option>';for(let row=0;row<rows;row++)for(let col=0;col<cols;col++){const o=document.createElement('option');o.value=String(row*cols+col);o.textContent=(row+1)+'행 '+(col+1)+'열';el('tile').appendChild(o);}el('tile').value=String(previous);el('tileHint').textContent=coordinates?'현재 위치: '+(coordinates.row+1)+'행 '+(coordinates.column+1)+'열':'위치가 맞지 않으면 직접 선택해 주세요.';}
function signature(c){return [c.framePack&&c.framePack.id||'',c.gifName||'',c.columns||3,c.fps||8,c.speed||1,c.displayScale||100,c.offsetX||0,c.offsetY||0,c.includeGaps===true,c.gapPercent===undefined?30:c.gapPercent].join('|');}
function selectedGroup(){return Number(settings.wallGroup)||1;}
function wallKey(){return device+'::group:'+selectedGroup();}
function wallConfig(){const c={};['framePack','gifName','columns','fps','speed','displayScale','offsetX','offsetY','includeGaps','gapPercent'].forEach(k=>{if(settings[k]!==undefined)c[k]=settings[k];});return c;}
function show(){el('wallGroup').value=String(selectedGroup());el('model').value=String(settings.columns||3);tileOptions();el('fps').value=String(settings.fps||8);el('speed').value=String(settings.speed||1);el('displayScale').value=String(settings.displayScale||100);el('offsetX').value=String(settings.offsetX||0);el('offsetY').value=String(settings.offsetY||0);el('includeGaps').checked=settings.includeGaps===true;el('gapPercent').value=String(settings.gapPercent===undefined?30:settings.gapPercent);viewPreview();el('name').textContent=settings.gifName||'전체 GIF를 선택해 주세요.';clearTimeout(previewTimer);if(settings.framePack){const pack=settings.framePack;const started=Date.now();const draw=()=>{previewFrame(pack.frames[GifEngine.frameIndex(pack,(Date.now()-started)*(Number(settings.speed)||1))].image);previewTimer=setTimeout(draw,80);};draw();}else {previewFrame(settings.gifBase64?'data:image/gif;base64,'+settings.gifBase64:'default.gif');const draw=()=>{viewPreview();previewTimer=setTimeout(draw,80);};previewTimer=setTimeout(draw,80);}el('clickAction').value=settings.clickAction||'pause';el('clickTarget').value=settings.clickTarget||'';el('browser').value=settings.browser||'default';el('folderMode').value=settings.folderMode||'reuse';targetUI();}
function collect(){settings=Object.assign({},settings,{wallGroup:Number(el('wallGroup').value),columns:Number(el('model').value),tile:el('tile').value,fps:Number(el('fps').value),speed:Number(el('speed').value),displayScale:Number(el('displayScale').value),offsetX:Number(el('offsetX').value),offsetY:Number(el('offsetY').value),includeGaps:el('includeGaps').checked,gapPercent:Number(el('gapPercent').value),clickAction:el('clickAction').value,clickTarget:el('clickTarget').value.trim(),browser:el('browser').value,folderMode:el('folderMode').value});}
function save(){clearTimeout(pending);pending=null;if(!socket||socket.readyState!==1||!wallReady){el('saveState').textContent='연결 대기';status('기기 설정을 불러오는 중입니다.');return false;}editingUntil=Date.now()+800;
 const local={};['clickAction','clickTarget','browser','folderMode','tile','wallGroup'].forEach(k=>{if(settings[k]!==undefined)local[k]=settings[k];});socket.send(JSON.stringify({event:'setSettings',context:uuid,payload:local}));
 const config=wallConfig(),sig=signature(config);if(sig!==lastWallSignature){socket.send(JSON.stringify({event:'sendToPlugin',action,context:uuid,payload:{wallConfig:config,device,wallGroup:selectedGroup()}}));lastWallSignature=sig;}
 el('saveState').textContent='저장됨';return true;}
function queueSave(){collect();editingUntil=Date.now()+1200;el('saveState').textContent='저장 중…';clearTimeout(pending);pending=setTimeout(save,350);}
function applyWall(c){const local={};['clickAction','clickTarget','browser','folderMode','tile','wallGroup'].forEach(k=>{if(settings[k]!==undefined)local[k]=settings[k];});settings=Object.assign(local,c||{});if(!settings.fps)settings.fps=8;lastWallSignature=signature(wallConfig());wallReady=true;show();}
function requestWall(){socket.send(JSON.stringify({event:'sendToPlugin',action,context:uuid,payload:{requestWall:true,device,wallGroup:selectedGroup()}}));}
function connect(port,id,event,info,actionInfo){uuid=id;let data={};try{data=JSON.parse(actionInfo||'{}');}catch{}action=data.action||'com.eska.ajazz.wall.play';device=data.device||'default';coordinates=data.payload&&data.payload.coordinates||null;settings=data.payload&&data.payload.settings||{};show();socket=new WebSocket('ws://127.0.0.1:'+port);socket.onopen=()=>{socket.send(JSON.stringify({event,uuid:id}));requestWall();socket.send(JSON.stringify({event:'getGlobalSettings',context:uuid}));status('전체 GIF를 불러오는 중…');};
 socket.onmessage=e=>{let m;try{m=JSON.parse(e.data);}catch{return;}
 if(m.event==='didReceiveSettings'&&Date.now()>=editingUntil&&Date.now()>=groupGuardUntil&&!pending){settings=Object.assign({},settings,m.payload.settings||{});show();}
 else if(m.event==='didReceiveGlobalSettings'){const walls=m.payload.settings&&m.payload.settings.walls||{};if(wallReady&&!pending&&Date.now()>=editingUntil)applyWall(walls[wallKey()]||(selectedGroup()===1?(walls[device]||walls.default):null)||{});}
 else if(m.event==='sendToPropertyInspector'){const p=m.payload||{};if(p.device)device=p.device;if(p.coordinates)coordinates=p.coordinates;if(p.wallConfig&&(p.wallGroup===undefined||Number(p.wallGroup)===selectedGroup())&&p.ready!==false&&!pending&&Date.now()>=editingUntil)applyWall(p.wallConfig);if(p.ready===false)setTimeout(requestWall,500);if(p.status)status(p.status);}
 };socket.onclose=()=>{wallReady=false;status('연결이 끊겼습니다. AJAZZ를 다시 실행해 주세요.');};}
el('wallGroup').onchange=()=>{
 if(!socket||socket.readyState!==1||!wallReady){el('wallGroup').value=String(selectedGroup());status('연결 후 그룹을 변경해 주세요.');return;}
 if(pending){save();} // Flush edits to the old group before switching.
 const next=Number(el('wallGroup').value),local={};['clickAction','clickTarget','browser','folderMode','tile'].forEach(k=>{if(settings[k]!==undefined)local[k]=settings[k];});
 local.wallGroup=next;settings=local;groupGuardUntil=Date.now()+1200;++conversion;el('file').disabled=false;wallReady=false;editingUntil=0;lastWallSignature='';previewRevision++;previewImage=null;clearTimeout(previewTimer);
 socket.send(JSON.stringify({event:'setSettings',context:uuid,payload:local}));
 socket.send(JSON.stringify({event:'sendToPlugin',action,context:uuid,payload:{settings:local}}));
 show();requestWall();status('그룹 '+next+' 설정을 불러오는 중…');
};
['fps','speed','displayScale','offsetX','offsetY','includeGaps','gapPercent','browser','folderMode','tile'].forEach(id=>el(id).onchange=()=>{collect();viewPreview();save();});el('model').onchange=()=>{collect();tileOptions();viewPreview();save();};el('resetView').onclick=()=>{settings.displayScale=100;settings.offsetX=0;settings.offsetY=0;show();save();};el('clickAction').onchange=()=>{targetUI();collect();save();};el('clickTarget').oninput=queueSave;el('clickTarget').onblur=()=>{collect();save();};el('clickTarget').onkeydown=e=>{if(e.key==='Enter'){collect();save();el('clickTarget').blur();}};
let pickerToken=null,pickerTimer=null;
function finishPicker(){pickerToken=null;clearTimeout(pickerTimer);el('browse').disabled=false;}
function pollPicker(token,kind,deadline){
 if(pickerToken!==token)return;
 if(Date.now()>deadline){finishPicker();status('선택 시간이 지나 종료했습니다. 다시 선택해 주세요.');return;}
 const xhr=new XMLHttpRequest();xhr.open('GET','picker-results/'+token+'.json?t='+Date.now());
 xhr.onload=()=>{if(pickerToken!==token)return;let data;try{data=JSON.parse(xhr.responseText);}catch{pickerTimer=setTimeout(()=>pollPicker(token,kind,deadline),400);return;}
  finishPicker();if(data.error){status('오류: '+data.error);return;}if(data.cancelled){status('선택을 취소했습니다.');return;}
  if(el('clickAction').value!==kind){status('버튼 동작이 변경되어 경로를 적용하지 않았습니다.');return;}
  el('clickTarget').value=data.path||'';collect();save();status('선택한 경로를 저장했습니다.');
 };xhr.onerror=()=>{if(pickerToken===token)pickerTimer=setTimeout(()=>pollPicker(token,kind,deadline),400);};xhr.send();
}
el('browse').onclick=()=>{
 if(!socket||socket.readyState!==1){status('연결을 확인해 주세요.');return;}
 const kind=el('clickAction').value;if(!['folder','file'].includes(kind))return;
 const token='p'+Date.now().toString(36)+Math.random().toString(36).slice(2);pickerToken=token;el('browse').disabled=true;
 const raw=unescape(encodeURIComponent(JSON.stringify({kind:kind,token:token,initial:el('clickTarget').value})));
 const url='eskaajazzwall://pick/'+btoa(raw).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
 socket.send(JSON.stringify({event:'openUrl',payload:{url:url}}));status('Windows 선택창에서 '+(kind==='folder'?'폴더':'파일')+'를 선택해 주세요.');pollPicker(token,kind,Date.now()+180000);
};
el('file').onchange=function(){const f=this.files[0];if(!f)return;if(f.size>50*1024*1024){status('오류: 원본 GIF는 50MB 이하로 선택해 주세요.');return;}collect();const own=++conversion;el('file').disabled=true;status('GIF를 버튼 크기로 최적화하는 중…');const r=new FileReader();r.onerror=()=>{el('file').disabled=false;status('오류: 파일을 읽지 못했습니다.');};r.onload=async()=>{try{const pack=await GifEngine.optimize(r.result,percent=>{if(own===conversion)status('전체 GIF 최적화 중 '+percent+'%');},{width:(settings.columns||3)*144,height:(settings.columns===5?3:2)*144});if(own!==conversion)return;collect();settings=Object.assign({},settings,{framePack:pack,gifName:f.name});delete settings.gifBase64;show();save();status('최적화 완료: '+pack.originalWidth+'×'+pack.originalHeight+' → 전체 버튼 분할 · '+pack.originalFrames+' → '+pack.frames.length+'프레임');}catch(error){if(own===conversion)status('오류: '+error.message);}finally{if(own===conversion)el('file').disabled=false;}};r.readAsArrayBuffer(f);};
el('sample').onclick=()=>{collect();const own=++conversion;const xhr=new XMLHttpRequest();xhr.open('GET','default.gif');xhr.responseType='arraybuffer';xhr.onload=async()=>{try{status('기본 GIF를 준비하는 중…');const pack=await GifEngine.optimize(xhr.response,null,{width:(settings.columns||3)*144,height:(settings.columns===5?3:2)*144});if(own!==conversion)return;settings.framePack=pack;settings.gifName='기본 GIF';show();save();status('전체 GIF를 설정했습니다.');}catch(e){status('오류: '+e.message);}};xhr.send();};
el('testAction').onclick=()=>{try{collect();GifActions.target(settings);if(!save())return;socket.send(JSON.stringify({event:'sendToPlugin',action:action,context:uuid,payload:{settings:{clickAction:settings.clickAction,clickTarget:settings.clickTarget,browser:settings.browser,folderMode:settings.folderMode,tile:settings.tile,wallGroup:selectedGroup()}}}));socket.send(JSON.stringify({event:'sendToPlugin',action:action,context:uuid,payload:{testClick:true}}));}catch(e){status('오류: '+e.message);}};
el('copy').onclick=async()=>{const log=JSON.stringify({plugin:'AJAZZ GIF Wall 1.2.0',status:lastStatus,wallGroup:selectedGroup(),fps:settings.fps||8,includeGaps:settings.includeGaps===true,gapPercent:settings.gapPercent,action:settings.clickAction||'pause',browser:settings.browser||'default',time:new Date().toISOString()},null,2);try{await navigator.clipboard.writeText(log);status('진단 내용을 복사했습니다.');}catch{window.prompt('아래 내용을 복사해 주세요.',log);}};
window.addEventListener('beforeunload',()=>{if(pending){save();}});window.connectElgatoStreamDeckSocket=connect;window.connectMiraBoxSDSocket=connect;window.connectSocket=connect;
})();
